/*
 Copyright (C) Johan Ceuppens 2011-2012
*/
#include<string>

namespace zelda
{

const char *cs(std::string s);


}
