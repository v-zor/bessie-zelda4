#ifndef _ROOM1_H_
#define _ROOM1_H_

#include "Room.h"

namespace zelda
{
namespace main
{

class Room1 : public Room 
{
public:
	Room1();
	virtual ~Room1();


};

}
}

#endif