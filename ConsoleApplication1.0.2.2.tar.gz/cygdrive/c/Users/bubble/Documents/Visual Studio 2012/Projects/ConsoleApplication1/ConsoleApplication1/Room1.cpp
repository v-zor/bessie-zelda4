#include "Room1.h"

namespace zelda
{
namespace main
{

Room1::Room1() : Room()
{}

Room1::~Room1()
{}


}//namespace main
}//namespace zelda