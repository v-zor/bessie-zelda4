#include "Room.h"

namespace zelda
{
namespace main
{

Room::Room()
{}

Room::~Room()
{}


}//namespace main
}//namespace zelda