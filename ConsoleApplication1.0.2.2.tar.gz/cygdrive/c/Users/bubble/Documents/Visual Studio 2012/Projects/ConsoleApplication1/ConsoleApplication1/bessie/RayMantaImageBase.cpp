/*
 Copyright (C) Johan Ceuppens 2011
*/
#include "RayMantaImageBase.h"
