/*
 Copyright (C) Johan Ceuppens 2011-2012
*/
#include"util.h"

namespace zelda
{
	
const char *cs(std::string s)
{
	return s.c_str();
}

}
