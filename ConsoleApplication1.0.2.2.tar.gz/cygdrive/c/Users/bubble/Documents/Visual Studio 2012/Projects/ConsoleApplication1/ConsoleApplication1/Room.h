#ifndef _ROOM_H_
#define _ROOM_H_

namespace zelda
{
namespace main
{

class Room 
{
public:
	Room();
	virtual ~Room();


};

}
}

#endif